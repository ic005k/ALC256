#ifndef _KERN_MPQUEUE_H
#define _KERN_MPQUEUE_H
#include <kern/locks.h>

__BEGIN_DECLS


__END_DECLS


#endif /* _KERN_QUEUE_H */
