//
//  UserKernelShared.h
//  AppleALC
//
//  Created by Nick on 10/14/20.
//  Copyright © 2020 vit9696. All rights reserved.
//

#ifndef UserKernelShared_h
#define UserKernelShared_h

enum {
	kMethodExecuteVerb,
	
	kNumberOfMethods // Must be last
};

#endif /* UserKernelShared_h */
